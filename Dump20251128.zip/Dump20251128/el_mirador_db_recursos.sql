-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: el_mirador_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recursos`
--

DROP TABLE IF EXISTS `recursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recursos` (
  `id_recurso` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `descripcion` text,
  `capacidad` int NOT NULL DEFAULT '1',
  `precio_base` decimal(38,2) DEFAULT NULL,
  `imagen_url` varchar(255) DEFAULT NULL,
  `id_tipo` int NOT NULL,
  `estado` enum('DISPONIBLE','MANTENIMIENTO','FUERA_DE_SERVICIO') DEFAULT 'DISPONIBLE',
  `version` bigint DEFAULT NULL,
  PRIMARY KEY (`id_recurso`),
  KEY `fk_recursos_tipo` (`id_tipo`),
  CONSTRAINT `fk_recursos_tipo` FOREIGN KEY (`id_tipo`) REFERENCES `tipos_recurso` (`id_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recursos`
--

LOCK TABLES `recursos` WRITE;
/*!40000 ALTER TABLE `recursos` DISABLE KEYS */;
INSERT INTO `recursos` VALUES (1,'Bungalow Matrimonial 103','Vista panorámica al valle, cama Queen, TV Cable',2,160.00,NULL,1,'DISPONIBLE',0),(2,'Bungalow Matrimonial 104','Cerca a la orilla del río, terraza privada, frigobar',2,180.00,NULL,1,'DISPONIBLE',0),(3,'Bungalow Matrimonial 105','Ubicación tranquila zona alta, cama King',2,150.00,NULL,1,'DISPONIBLE',0),(4,'Bungalow Familiar 106','Una habitación con camarotes, sala de estar',4,250.00,NULL,1,'DISPONIBLE',0),(5,'Bungalow Familiar 107','Vista a la piscina, kitchenette equipado',4,260.00,NULL,1,'DISPONIBLE',0),(6,'Bungalow Familiar 201','Dúplex rústico, dos baños, balcón amplio',6,350.00,NULL,1,'DISPONIBLE',0),(7,'Bungalow Familiar 202','Especial para grupos, zona de parrilla privada',8,420.00,NULL,1,'DISPONIBLE',0),(8,'Bungalow Premium 203','La mejor vista del club, acabados de lujo, jacuzzi',6,500.00,NULL,1,'DISPONIBLE',0),(9,'Mesa Zona Río 01','Mesa de madera junto al río Santa Eulalia',6,30.00,NULL,2,'DISPONIBLE',0),(10,'Mesa Zona Río 02','Mesa de madera junto al río Santa Eulalia',6,30.00,NULL,2,'DISPONIBLE',0),(11,'Mesa Zona Río 03','Ubicación preferencial bajo sombra natural',8,35.00,NULL,2,'DISPONIBLE',0),(12,'Mesa Zona Río 04','Ubicación preferencial bajo sombra natural',8,35.00,NULL,2,'DISPONIBLE',0),(13,'Box Piscina A','Lounge privado frente a la piscina, incluye sombrilla grande',8,50.00,NULL,2,'DISPONIBLE',0),(14,'Box Piscina B','Lounge privado frente a la piscina, incluye sombrilla grande',8,50.00,NULL,2,'DISPONIBLE',0),(15,'Mesa Familiar Piscina 01','Mesa redonda familiar cerca a patera de niños',5,25.00,NULL,2,'DISPONIBLE',0),(16,'Mesa Familiar Piscina 02','Mesa redonda familiar cerca a patera de niños',5,25.00,NULL,2,'DISPONIBLE',0),(17,'Mesa Campestre 10','Zona de gras, ideal para picnic familiar',6,15.00,NULL,2,'DISPONIBLE',0),(18,'Mesa Campestre 11','Zona de gras, ideal para picnic familiar',6,15.00,NULL,2,'DISPONIBLE',0),(19,'Mesa Campestre 12','Cerca a los juegos infantiles',4,15.00,NULL,2,'DISPONIBLE',0),(20,'Mesa Campestre 13','Cerca a los juegos infantiles',4,15.00,NULL,2,'DISPONIBLE',0),(21,'Mesa Grande Eventos','Tablón largo para celebraciones o cumpleaños',15,80.00,NULL,2,'DISPONIBLE',0),(22,'Zona de Parrilla 01','Parrilla de ladrillo, lavadero y mesa auxiliar',10,40.00,NULL,3,'DISPONIBLE',0),(23,'Zona de Parrilla 02','Parrilla de ladrillo, lavadero y mesa auxiliar',10,40.00,NULL,3,'DISPONIBLE',0),(24,'Zona de Parrilla 03','Parrilla amplia techada',12,50.00,NULL,3,'DISPONIBLE',0),(25,'Cancha de Voley','Cancha de césped para voley o bádminton (por hora)',12,30.00,NULL,3,'DISPONIBLE',0),(26,'Loza Deportiva Multi','Cemento, para fulbito o basket (por hora)',14,40.00,NULL,3,'DISPONIBLE',0);
/*!40000 ALTER TABLE `recursos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-28 21:35:31
